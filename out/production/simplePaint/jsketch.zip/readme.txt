By: Harsh Amin

JSketch

How to: Use selector, shape and erase tools with the color pallette 
       to make a sketch.

Save/Load: files are saved and loaded in .sketch format

View Mode: Adjust view to full screen or fit to window






Origin of images:
thickness lines, mouse, eraser:
http://www.stanleywilliamhayter.com/anglais/fields_a.html

