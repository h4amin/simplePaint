interface Observer {
    public void updateObserver();
}
